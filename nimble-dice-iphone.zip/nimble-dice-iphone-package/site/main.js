import { buildQuickFormula, rollNimbleFormula, splitFormulaModifier } from './engine/nimble-app-roll.js';

const app = document.querySelector('#app');
const SIDES = [4, 6, 8, 10, 12, 20];
const STORAGE_KEY = 'nimble-dice-app-v5';
const PALETTE = ['#3a2c1c', '#26394e', '#472629', '#263e31', '#3b2c50', '#45413a'];
const COLORS = ['#d5ad62', '#82a9cf', '#d57c73', '#86b68c', '#aa8ad1', '#a7a39a'];
const id = () => (crypto?.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`);

function seedData() {
  return {
    folders: [
      { id: 'combat', name: 'COMBAT', color: '#3a2c1c', open: true },
      { id: 'magic', name: 'MAGIC', color: '#26394e', open: false },
    ],
    sets: [
      { id: 'heavy-strike', folderId: 'combat', name: 'Heavy Strike', formula: '2d8+5 ADV1', vicious: false, color: '#3a2c1c' },
      { id: 'fireball', folderId: 'combat', name: 'Fireball', formula: '4d6+2', vicious: false, color: '#472629' },
      { id: 'arcane-bolt', folderId: 'magic', name: 'Arcane Bolt', formula: '2d10+5', vicious: false, color: '#26394e' },
    ],
  };
}

function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
    if (saved && Array.isArray(saved.folders) && Array.isArray(saved.sets)) return saved;
  } catch { /* reset corrupt local data to samples */ }
  const seeded = seedData();
  localStorage.setItem(STORAGE_KEY, JSON.stringify(seeded));
  return seeded;
}

const saved = loadState();
const state = {
  tab: 'roller',
  pool: [],
  rollerAdv: 0,
  rollerVicious: false,
  rollerResult: null,
  calcExpression: '',
  calcAdv: 0,
  calcVicious: false,
  calcResult: null,
  folders: saved.folders,
  sets: saved.sets,
  setResults: {},
  setAdv: 0,
  expandedFolder: saved.folders.find(f => f.open)?.id ?? saved.folders[0]?.id ?? null,
  folderPages: {},
  folderListPage: 0,
  colorTarget: null,
  editor: null,
  error: '',
};

function persistLibrary() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify({ folders: state.folders, sets: state.sets }));
}
function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch]);
}
function netLabel(value) {
  return value > 0 ? `ADV${value}` : value < 0 ? `DIS${Math.abs(value)}` : '';
}
function formulaDisplay(formula, extra = 0) {
  const split = splitFormulaModifier(formula);
  const net = Math.max(-10, Math.min(10, split.advantageLevel + extra));
  return `${split.formula}${net ? ` ${netLabel(net)}` : ''}`;
}
function svg(name, size = 22) {
  const paths = {
    dice: '<path d="m12 2 9 5v10l-9 5-9-5V7l9-5Z"/><path d="m3.3 7 8.7 5 8.7-5M12 12v10M7 4.8l10 10.4M17 4.8 7 15.2"/><circle cx="12" cy="7" r=".8" fill="currentColor" stroke="none"/><circle cx="8" cy="14" r=".8" fill="currentColor" stroke="none"/><circle cx="16" cy="14" r=".8" fill="currentColor" stroke="none"/>',
    calculator: '<rect x="4" y="2.5" width="16" height="19" rx="2"/><rect x="7" y="5.5" width="10" height="4" rx=".8"/><path d="M8 13h.01M12 13h.01M16 13h.01M8 17h.01M12 17h.01M16 17h.01" stroke-width="2.5"/>',
    folder: '<path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H10l2 2h6.5A2.5 2.5 0 0 1 21 9.5v8a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 17.5v-10Z"/><path d="M3.5 9h17"/>',
    folderPlus: '<path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H10l2 2h5.5A2.5 2.5 0 0 1 20 9.5v8a2.5 2.5 0 0 1-2.5 2.5h-12A2.5 2.5 0 0 1 3 17.5v-10Z"/><path d="M12 11v6M9 14h6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    edit: '<path d="m4 16.5-.8 4.3 4.3-.8L19 8.5 15.5 5 4 16.5Z"/><path d="m13.5 7 3.5 3.5"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 14h10l1-14M9 7V4h6v3"/>',
    chevron: '<path d="m7 10 5 5 5-5"/>',
    backspace: '<path d="M9 5H20v14H9l-7-7 7-7Z"/><path d="m12 9 6 6m0-6-6 6"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="m19.4 15 .1.1 1.1 1.8-1.7 2.9-2.1-.5a7.8 7.8 0 0 1-1.7 1l-.4 2.2h-3.4l-.4-2.2a7.8 7.8 0 0 1-1.7-1l-2.1.5-1.7-2.9 1.1-1.8a7 7 0 0 1 0-2l-1.1-1.8 1.7-2.9 2.1.5a7.8 7.8 0 0 1 1.7-1l.4-2.2h3.4l.4 2.2a7.8 7.8 0 0 1 1.7 1l2.1-.5 1.7 2.9-1.1 1.8a7 7 0 0 1 0 2Z" transform="translate(-1 -1) scale(1.08)"/>',
  };
  return `<svg viewBox="0 0 24 24" width="${size}" height="${size}" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${paths[name] || ''}</svg>`;
}

function header() {
  return `<header class="topbar"><div class="brand-lockup"><div class="brand-name">NIMBLE</div><div class="brand-sub">DICE &amp; TOOLS</div></div><span class="icon-button settings-button" aria-hidden="true">${svg('settings', 21)}</span></header>`;
}
function nav() {
  return `<nav class="bottom-nav" aria-label="Main navigation">
    <button data-tab="roller" class="nav-item ${state.tab === 'roller' ? 'active' : ''}">${svg('dice', 24)}<span>ROLLER</span></button>
    <button data-tab="calculator" class="nav-item ${state.tab === 'calculator' ? 'active' : ''}">${svg('calculator', 24)}<span>CALCULATOR</span></button>
    <button data-tab="sets" class="nav-item ${state.tab === 'sets' ? 'active' : ''}">${svg('folder', 24)}<span>DICE SETS</span></button>
  </nav>`;
}
function resultCard(result) {
  if (!result) return `<section class="result-card idle"><div class="result-heading"><span>LATEST RESULT</span><span></span></div><div class="result-total idle-total">—</div><div class="result-rolls"></div></section>`;
  const cls = result.kind.toLowerCase();
  return `<section class="result-card ${cls}"><div class="result-heading"><span>LATEST RESULT</span><strong>${result.kind}</strong></div><div class="result-total">${esc(result.total)}</div><div class="result-rolls">${result.dice.map((die, index) => `<span class="roll-value ${die.kept ? '' : 'dropped'}">${esc(die.value)}${index < result.dice.length - 1 ? ',' : ''}</span>`).join(' ')}</div></section>`;
}
function modifierControls(value, prefix = 'mod') {
  return `<div class="modifier-row">
    <button class="modifier-btn adv-btn" data-mod="adv" data-prefix="${prefix}">ADV${value > 0 ? `<span class="mod-count">${value}</span>` : ''}</button>
    <div class="net-indicator">${value > 0 ? `ADV${value}` : value < 0 ? `DIS${Math.abs(value)}` : 'NORMAL'}</div>
    <button class="modifier-btn dis-btn" data-mod="dis" data-prefix="${prefix}">DIS${value < 0 ? `<span class="mod-count">${Math.abs(value)}</span>` : ''}</button>
  </div>`;
}
function viciousToggle(value, key) {
  return `<button class="vicious-control ${value ? 'on' : ''}" data-vicious="${key}" aria-pressed="${value}"><span>VICIOUS</span><span class="toggle-track"><i></i></span></button>`;
}
function rollerScreen() {
  const counts = Object.fromEntries(SIDES.map(side => [side, state.pool.filter(x => x === side).length]));
  return `<section class="screen roller-screen">
    ${resultCard(state.rollerResult)}
    <div class="section-label">QUICK ROLLER</div>
    <div class="dice-grid">${SIDES.map(side => `<button class="die-tap ${counts[side] ? 'selected' : ''}" data-die="${side}" aria-label="Add d${side}">
      <span class="die-art"> <img src="./assets/d${side}.png" alt="d${side} polyhedral die">${counts[side] ? `<span class="die-count">${counts[side]}</span>` : ''}</span>
      <span class="die-name">d${side}</span>
    </button>`).join('')}</div>
    ${modifierControls(state.rollerAdv, 'roller')}
    ${viciousToggle(state.rollerVicious, 'roller')}
    <div class="action-row"><button class="clear-button" data-action="clear-roller">CLEAR</button><button class="roll-button" data-action="roll-roller">${svg('dice', 19)} ROLL</button></div>
    ${state.error ? `<div class="inline-error">${esc(state.error)}</div>` : ''}
  </section>`;
}
function calculatorScreen() {
  const expression = `${state.calcExpression}${state.calcAdv ? ` ${state.calcAdv > 0 ? `ADV${state.calcAdv}` : `DIS${Math.abs(state.calcAdv)}`}` : ''}`;
  const keys = ['7', '8', '9', 'd', '4', '5', '6', '+', '1', '2', '3', '-', '0', 'ADV', 'DIS', 'BACK'];
  return `<section class="screen calculator-screen">
    ${resultCard(state.calcResult)}
    <div class="expression-box"><div class="section-label">EXPRESSION</div><div class="expression-value">${esc(expression || ' ')}</div></div>
    <div class="calculator-keypad">${keys.map(k => `<button class="key ${k === 'ADV' ? 'adv-key' : k === 'DIS' ? 'dis-key' : k === 'BACK' ? 'back-key' : ''}" data-key="${k}">${k === 'BACK' ? svg('backspace', 21) : k}</button>`).join('')}</div>
    ${viciousToggle(state.calcVicious, 'calculator')}
    <div class="action-row"><button class="clear-button" data-action="clear-calculator">CLEAR</button><button class="roll-button" data-action="roll-calculator">ROLL</button></div>
    ${state.error ? `<div class="inline-error">${esc(state.error)}</div>` : ''}
  </section>`;
}
function colorPalette(target) {
  return `<div class="color-palette">${PALETTE.map((color, i) => `<button data-color="${color}" data-color-target="${target}" aria-label="Choose color" style="--swatch:${color};--swatch-edge:${COLORS[i]}"></button>`).join('')}</div>`;
}
function setRow(set) {
  const result = state.setResults[set.id];
  const target = `set:${set.id}`;
  return `<div class="set-row-wrap">
    <button class="set-row ${result ? 'has-result' : ''}" data-roll-set="${set.id}" style="--set-bg:${set.color || '#302719'};--set-edge:${set.color || '#80643A'}">
      <span class="set-main"><span class="set-name">${esc(set.name)}</span><span class="set-formula">${esc(formulaDisplay(set.formula, state.setAdv))}${set.vicious ? ' v' : ''}</span></span>
      <span class="set-result">${result ? `<span class="set-total">${esc(result.total)}</span><span class="set-kind ${result.kind.toLowerCase()}">${result.kind}</span><span class="set-dice">${result.dice.map((d, i) => `<span class="${d.kept ? '' : 'dropped'}">${esc(d.value)}${i < result.dice.length - 1 ? ',' : ''}</span>`).join(' ')}</span>` : `<span class="set-ready">ROLL</span>`}</span>
    </button>
    <div class="set-tools"><button data-edit-set="${set.id}" aria-label="Edit ${esc(set.name)}">${svg('edit', 14)}</button><button data-toggle-palette="${target}" aria-label="Change set color">◉</button><button data-delete-set="${set.id}" aria-label="Delete ${esc(set.name)}">${svg('trash', 14)}</button></div>
    ${state.colorTarget === target ? colorPalette(target) : ''}
  </div>`;
}
function folderBlock(folder) {
  const isOpen = state.expandedFolder === folder.id;
  const all = state.sets.filter(s => s.folderId === folder.id);
  const pageSize = 3;
  const page = Math.min(state.folderPages[folder.id] || 0, Math.max(0, Math.ceil(all.length / pageSize) - 1));
  const visible = all.slice(page * pageSize, page * pageSize + pageSize);
  const target = `folder:${folder.id}`;
  return `<section class="folder-block">
    <div class="folder-heading" style="--folder-bg:${folder.color || '#302719'}">
      <button class="folder-toggle" data-toggle-folder="${folder.id}">${svg('folder', 19)}<span>${esc(folder.name)}</span>${svg('chevron', 15)}</button>
      <div class="folder-tools"><button data-add-set="${folder.id}" aria-label="Add set to ${esc(folder.name)}">${svg('plus', 18)}</button><button data-toggle-palette="${target}" aria-label="Change folder color">◉</button></div>
    </div>
    ${state.colorTarget === target ? colorPalette(target) : ''}
    ${isOpen ? `<div class="folder-sets">${visible.map(setRow).join('') || '<div class="empty-folder"></div>'}</div>${all.length > pageSize ? `<div class="folder-pager"><button data-page-folder="${folder.id}" data-dir="-1" ${page === 0 ? 'disabled' : ''}>‹</button><span>${page + 1} / ${Math.ceil(all.length / pageSize)}</span><button data-page-folder="${folder.id}" data-dir="1" ${page >= Math.ceil(all.length / pageSize) - 1 ? 'disabled' : ''}>›</button></div>` : ''}` : ''}
  </section>`;
}
function setsScreen() {
  const folderPageSize = 2;
  const folderPages = Math.max(1, Math.ceil(state.folders.length / folderPageSize));
  const currentFolderPage = Math.min(state.folderListPage, folderPages - 1);
  const visibleFolders = state.folders.slice(currentFolderPage * folderPageSize, currentFolderPage * folderPageSize + folderPageSize);
  return `<section class="screen sets-screen">
    <div class="sets-heading"><div class="section-label">DICE SETS</div><div class="sets-heading-tools"><button data-action="add-folder" aria-label="Add folder">${svg('folderPlus', 19)}</button><button data-action="add-set" aria-label="Add dice set">${svg('plus', 20)}</button></div></div>
    <div class="folders-list">${visibleFolders.map(folderBlock).join('') || '<div class="empty-library"></div>'}</div>
    ${folderPages > 1 ? `<div class="folder-pager"><button data-page-folders="-1" ${currentFolderPage === 0 ? 'disabled' : ''}>‹</button><span>${currentFolderPage + 1} / ${folderPages}</span><button data-page-folders="1" ${currentFolderPage >= folderPages - 1 ? 'disabled' : ''}>›</button></div>` : ''}
    <div class="set-modifier-area">${modifierControls(state.setAdv, 'sets')}</div>
    ${state.error ? `<div class="inline-error">${esc(state.error)}</div>` : ''}
  </section>`;
}
function editorMarkup() {
  if (!state.editor) return '';
  const e = state.editor;
  const formula = `${e.formula}${e.adv ? ` ${e.adv > 0 ? `ADV${e.adv}` : `DIS${Math.abs(e.adv)}`}` : ''}`;
  const keys = ['7', '8', '9', 'd', '4', '5', '6', '+', '1', '2', '3', '-', '0', 'ADV', 'DIS', 'BACK'];
  return `<div class="editor-overlay"><section class="editor-sheet">
    <div class="editor-top"><span>${e.id ? 'EDIT SET' : 'NEW SET'}</span><button data-action="close-editor" aria-label="Close">×</button></div>
    <input class="set-name-input" id="editor-name" placeholder="Set name" maxlength="36" value="${esc(e.name)}" autocomplete="off">
    <div class="editor-expression">${esc(formula || ' ')}</div>
    <div class="editor-keypad">${keys.map(k => `<button class="key ${k === 'ADV' ? 'adv-key' : k === 'DIS' ? 'dis-key' : k === 'BACK' ? 'back-key' : ''}" data-editor-key="${k}">${k === 'BACK' ? svg('backspace', 19) : k}</button>`).join('')}</div>
    <div class="editor-options"><label><input type="checkbox" id="editor-vicious" ${e.vicious ? 'checked' : ''}> VICIOUS</label><select id="editor-folder">${state.folders.map(f => `<option value="${f.id}" ${f.id === e.folderId ? 'selected' : ''}>${esc(f.name)}</option>`).join('')}</select></div>
    <div class="editor-actions"><button class="clear-button" data-action="editor-clear-formula">CLEAR</button><button class="clear-button" data-action="close-editor">CANCEL</button><button class="roll-button" data-action="save-set">SAVE</button></div>
    ${state.error ? `<div class="inline-error">${esc(state.error)}</div>` : ''}
  </section></div>`;
}
function render() {
  const screen = state.tab === 'roller' ? rollerScreen() : state.tab === 'calculator' ? calculatorScreen() : setsScreen();
  app.innerHTML = `<div class="app-shell">${header()}${screen}</div>${nav()}${editorMarkup()}`;
  bind();
}
function adjustModifier(prefix, mod) {
  const prop = prefix === 'roller' ? 'rollerAdv' : prefix === 'calculator' ? 'calcAdv' : 'setAdv';
  state[prop] = Math.max(-10, Math.min(10, state[prop] + (mod === 'adv' ? 1 : -1)));
}
function showError(error) {
  state.error = String(error?.message || error || 'Unable to roll this formula.');
  render();
}
function runRoll(formula, options = {}) {
  state.error = '';
  try {
    return rollNimbleFormula(formula, options);
  } catch (error) {
    state.error = error.message || 'Invalid formula.';
    return null;
  }
}
function rollQuick() {
  const formula = buildQuickFormula(state.pool);
  if (!formula) { state.error = 'Select at least one die.'; render(); return; }
  const result = runRoll(formula, { advantageLevel: state.rollerAdv, vicious: state.rollerVicious });
  if (result) state.rollerResult = result;
  render();
}
function rollCalculator() {
  const result = runRoll(state.calcExpression, { advantageLevel: state.calcAdv, vicious: state.calcVicious });
  if (result) state.calcResult = result;
  render();
}
function rollSet(setId) {
  const set = state.sets.find(s => s.id === setId);
  if (!set) return;
  const result = runRoll(set.formula, { advantageLevel: state.setAdv, vicious: set.vicious });
  if (result) state.setResults[setId] = result;
  render();
}
function openEditor(set = null, folderId = null) {
  const split = set ? splitFormulaModifier(set.formula) : { formula: '', advantageLevel: 0 };
  state.error = '';
  state.editor = {
    id: set?.id ?? null,
    name: set?.name ?? '',
    formula: split.formula,
    adv: split.advantageLevel,
    vicious: Boolean(set?.vicious),
    folderId: set?.folderId ?? folderId ?? state.expandedFolder ?? state.folders[0]?.id ?? '',
    color: set?.color ?? state.folders.find(f => f.id === (folderId || state.expandedFolder))?.color ?? PALETTE[0],
  };
  render();
}
function saveEditor() {
  const e = state.editor;
  if (!e) return;
  const name = app.querySelector('#editor-name')?.value.trim() || '';
  const vicious = Boolean(app.querySelector('#editor-vicious')?.checked);
  const folderId = app.querySelector('#editor-folder')?.value || e.folderId;
  if (!name) { state.error = 'Enter a set name.'; render(); return; }
  if (!e.formula.trim()) { state.error = 'Enter a formula.'; render(); return; }
  const formula = `${e.formula.trim()}${e.adv ? ` ${e.adv > 0 ? `ADV${e.adv}` : `DIS${Math.abs(e.adv)}`}` : ''}`;
  try { rollNimbleFormula(formula, { vicious }); }
  catch (error) { state.error = error.message; render(); return; }
  if (e.id) {
    const current = state.sets.find(s => s.id === e.id);
    if (current) Object.assign(current, { name, formula, vicious, folderId, color: e.color });
  } else {
    state.sets.push({ id: id(), folderId, name, formula, vicious, color: e.color || PALETTE[0] });
  }
  persistLibrary();
  state.editor = null;
  state.error = '';
  render();
}
function addFolder() {
  const name = prompt('Folder name');
  if (!name?.trim()) return;
  const folder = { id: id(), name: name.trim().slice(0, 28).toUpperCase(), color: PALETTE[state.folders.length % PALETTE.length] };
  state.folders.push(folder);
  state.expandedFolder = folder.id;
  persistLibrary();
  render();
}
function deleteSet(setId) {
  const set = state.sets.find(s => s.id === setId);
  if (!set) return;
  if (!confirm(`Delete “${set.name}”?`)) return;
  state.sets = state.sets.filter(s => s.id !== setId);
  delete state.setResults[setId];
  persistLibrary();
  render();
}
function applyColor(target, color) {
  const [type, targetId] = target.split(':');
  if (type === 'folder') {
    const folder = state.folders.find(f => f.id === targetId);
    if (folder) folder.color = color;
  } else {
    const set = state.sets.find(s => s.id === targetId);
    if (set) set.color = color;
  }
  state.colorTarget = null;
  persistLibrary();
  render();
}
function bind() {
  app.querySelectorAll('[data-tab]').forEach(button => button.addEventListener('click', () => { state.tab = button.dataset.tab; state.error = ''; render(); }));
  app.querySelectorAll('[data-die]').forEach(button => button.addEventListener('click', () => { state.pool.push(Number(button.dataset.die)); state.error = ''; render(); }));
  app.querySelectorAll('[data-mod]').forEach(button => button.addEventListener('click', () => { adjustModifier(button.dataset.prefix, button.dataset.mod); state.error = ''; render(); }));
  app.querySelectorAll('[data-vicious]').forEach(button => button.addEventListener('click', () => {
    const key = button.dataset.vicious === 'roller' ? 'rollerVicious' : 'calcVicious';
    state[key] = !state[key]; render();
  }));
  app.querySelectorAll('[data-key]').forEach(button => button.addEventListener('click', () => {
    const k = button.dataset.key;
    if (k === 'ADV' || k === 'DIS') adjustModifier('calculator', k.toLowerCase());
    else if (k === 'BACK') state.calcExpression = state.calcExpression.slice(0, -1);
    else state.calcExpression += k;
    state.error = ''; render();
  }));
  app.querySelectorAll('[data-editor-key]').forEach(button => button.addEventListener('click', () => {
    if (!state.editor) return;
    const k = button.dataset.editorKey;
    if (k === 'ADV' || k === 'DIS') state.editor.adv = Math.max(-10, Math.min(10, state.editor.adv + (k === 'ADV' ? 1 : -1)));
    else if (k === 'BACK') state.editor.formula = state.editor.formula.slice(0, -1);
    else state.editor.formula += k;
    state.error = ''; render();
  }));
  app.querySelectorAll('[data-action]').forEach(button => button.addEventListener('click', () => {
    const action = button.dataset.action;
    if (action === 'roll-roller') rollQuick();
    else if (action === 'clear-roller') { state.pool = []; state.rollerAdv = 0; state.rollerVicious = false; state.rollerResult = null; state.error = ''; render(); }
    else if (action === 'roll-calculator') rollCalculator();
    else if (action === 'clear-calculator') { state.calcExpression = ''; state.calcAdv = 0; state.calcVicious = false; state.calcResult = null; state.error = ''; render(); }
    else if (action === 'add-set') openEditor();
    else if (action === 'add-folder') addFolder();
    else if (action === 'editor-clear-formula') { if (state.editor) { state.editor.formula = ''; state.editor.adv = 0; state.error = ''; render(); } }
    else if (action === 'save-set') saveEditor();
    else if (action === 'close-editor') { state.editor = null; state.error = ''; render(); }
  }));
  app.querySelectorAll('[data-roll-set]').forEach(button => button.addEventListener('click', () => rollSet(button.dataset.rollSet)));
  app.querySelectorAll('[data-edit-set]').forEach(button => button.addEventListener('click', () => { const set = state.sets.find(s => s.id === button.dataset.editSet); if (set) openEditor(set); }));
  app.querySelectorAll('[data-delete-set]').forEach(button => button.addEventListener('click', () => deleteSet(button.dataset.deleteSet)));
  app.querySelectorAll('[data-toggle-folder]').forEach(button => button.addEventListener('click', () => { state.expandedFolder = state.expandedFolder === button.dataset.toggleFolder ? null : button.dataset.toggleFolder; state.colorTarget = null; render(); }));
  app.querySelectorAll('[data-add-set]').forEach(button => button.addEventListener('click', () => openEditor(null, button.dataset.addSet)));
  app.querySelectorAll('[data-toggle-palette]').forEach(button => button.addEventListener('click', () => { state.colorTarget = state.colorTarget === button.dataset.togglePalette ? null : button.dataset.togglePalette; render(); }));
  app.querySelectorAll('[data-color]').forEach(button => button.addEventListener('click', () => applyColor(button.dataset.colorTarget, button.dataset.color)));
  app.querySelectorAll('[data-page-folders]').forEach(button => button.addEventListener('click', () => {
    const pageSize = 2;
    const pageCount = Math.max(1, Math.ceil(state.folders.length / pageSize));
    state.folderListPage = Math.max(0, Math.min(pageCount - 1, state.folderListPage + Number(button.dataset.pageFolders)));
    const firstVisible = state.folders[state.folderListPage * pageSize];
    state.expandedFolder = firstVisible?.id ?? null;
    state.colorTarget = null;
    render();
  }));
  app.querySelectorAll('[data-page-folder]').forEach(button => button.addEventListener('click', () => {
    const fid = button.dataset.pageFolder;
    const current = state.folderPages[fid] || 0;
    state.folderPages[fid] = Math.max(0, current + Number(button.dataset.dir)); render();
  }));
  app.querySelector('#editor-name')?.addEventListener('input', event => { if (state.editor) state.editor.name = event.target.value; });
  app.querySelector('#editor-folder')?.addEventListener('change', event => { if (state.editor) state.editor.folderId = event.target.value; });
}

if ('serviceWorker' in navigator && location.protocol !== 'file:') {
  window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(() => {}));
}
render();
