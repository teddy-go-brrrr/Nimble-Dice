const CACHE = 'nimble-dice-v7-classic-gold';
const CORE = [
  './', './index.html', './main.js', './style.css', './manifest.webmanifest',
  './engine/index.js', './engine/config.js', './engine/nimble-app-roll.js',
  './assets/d4.png', './assets/d6.png', './assets/d8.png', './assets/d10.png', './assets/d12.png', './assets/d20.png',
  './icon-192.png', './icon-512.png'
];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(CORE)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request).then(response => {
    if (response.ok && new URL(event.request.url).origin === self.location.origin) {
      const copy = response.clone();
      caches.open(CACHE).then(cache => cache.put(event.request, copy));
    }
    return response;
  }).catch(() => caches.match('./index.html'))));
});
