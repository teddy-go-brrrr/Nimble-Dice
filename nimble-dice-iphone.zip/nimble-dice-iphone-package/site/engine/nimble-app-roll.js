import { evaluateDiceFormula, tokenize } from './index.js';

const VALID_SIDES = new Set([4, 6, 8, 10, 12, 20]);
const MAX_ADVANTAGE = 10;

export function splitFormulaModifier(input = '') {
  const text = String(input).trim();
  const match = text.match(/\s*(ADV|DIS)\s*(\d*)\s*$/i);
  if (!match) return { formula: text, advantageLevel: 0 };
  const magnitude = Math.max(1, Number.parseInt(match[2] || '1', 10));
  return {
    formula: text.slice(0, match.index).trim(),
    advantageLevel: match[1].toUpperCase() === 'ADV' ? magnitude : -magnitude,
  };
}

function clampAdvantage(level) {
  if (!Number.isFinite(level)) return 0;
  return Math.max(-MAX_ADVANTAGE, Math.min(MAX_ADVANTAGE, Math.trunc(level)));
}

function tokenAdvantage(modifiers = []) {
  for (const modifier of modifiers) {
    const m = String(modifier).match(/^([ad])(\d*)$/i);
    if (m) {
      const n = Math.max(1, Number.parseInt(m[2] || '1', 10));
      return m[1].toLowerCase() === 'a' ? n : -n;
    }
  }
  return 0;
}

function assertFormulaTokens(formula) {
  if (!formula || formula.length > 120) throw new Error('Enter a dice formula.');
  // The app deliberately exposes only Nimble's simple dice arithmetic keypad.
  if (!/^[0-9dD+\-\s]*$/.test(formula)) {
    throw new Error('Use dice, numbers, plus, and minus only.');
  }
  const tokens = tokenize(formula);
  if (!tokens.length) throw new Error('Enter a dice formula.');
  if (!tokens.some((t) => t.type === 'dice')) throw new Error('A formula needs at least one die.');
  if (tokens.some((t) => t.type === 'operator' && !['+', '-'].includes(t.operator))) {
    throw new Error('Only plus and minus are supported.');
  }
  let previous = 'start';
  for (const token of tokens) {
    const current = token.type === 'operator' ? token.operator : token.type;
    if (token.type === 'operator') {
      if (previous === 'start' || previous === '+' || previous === '-') throw new Error('Check the formula.');
    } else if (previous === 'static' || previous === 'dice') {
      throw new Error('Add a plus or minus between terms.');
    }
    if (token.type === 'dice' && !VALID_SIDES.has(token.sides)) {
      throw new Error(`Only d4, d6, d8, d10, d12, and d20 are supported (not d${token.sides}).`);
    }
    previous = current;
  }
  if (previous === '+' || previous === '-') throw new Error('The formula cannot end with an operator.');
  return tokens;
}

function resultDiceFromEngine(result) {
  const diceToken = result.tokens.find((token) => token.type === 'dice');
  return diceToken?.diceData?.dice ?? [];
}

/**
 * Nimble-aware roll adapter around the supplied @nimble/dice engine.
 * Only the first dice term is the primary pool. Later dice terms are additive
 * bonus dice and cannot independently turn the roll into a miss or critical.
 * The engine handles keep/drop, exploding criticals, and Vicious bonus dice.
 */
export function rollNimbleFormula(input, options = {}) {
  const split = splitFormulaModifier(input);
  const tokens = assertFormulaTokens(split.formula);
  const diceTokenIndex = tokens.findIndex((t) => t.type === 'dice');
  const primaryToken = tokens[diceTokenIndex];
  const embeddedAdv = tokenAdvantage(primaryToken.modifiers);
  const advantageLevel = clampAdvantage((split.advantageLevel || 0) + (options.advantageLevel || 0) + embeddedAdv);
  const vicious = Boolean(options.vicious || primaryToken.modifiers?.includes('v'));

  let total = 0;
  let sign = 1;
  const dice = [];
  let primaryDie = null;
  let primarySides = primaryToken.sides;
  let criticalHits = 0;

  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i];
    if (token.type === 'operator') {
      sign = token.operator === '-' ? -1 : 1;
      continue;
    }
    if (token.type === 'static') {
      total += sign * token.value;
      continue;
    }

    const isPrimaryTerm = i === diceTokenIndex;
    const notation = isPrimaryTerm
      ? `${token.count}d${token.sides}!${vicious ? 'v' : ''}${advantageLevel > 0 ? `a${advantageLevel}` : advantageLevel < 0 ? `d${Math.abs(advantageLevel)}` : ''}`
      : `${token.count}d${token.sides}`;

    // allowFumbles stays false so the upstream engine preserves the numeric total.
    // The fumble marker in the die breakdown is used to classify MISS separately.
    const evaluated = evaluateDiceFormula(notation, { allowFumbles: false });
    const tokenResult = evaluated.tokens.find((t) => t.type === 'dice');
    if (!tokenResult) throw new Error('Could not evaluate dice term.');
    const termDice = tokenResult.diceData.dice.map((die, index) => ({
      value: die.value,
      size: die.size,
      kept: die.kept,
      category: die.category,
      primaryTerm: isPrimaryTerm,
      index: dice.length + index,
    }));
    if (isPrimaryTerm) {
      const firstKeptBase = tokenResult.diceData.dice.find((die) =>
        die.kept && die.category !== 'explosion' && die.category !== 'vicious');
      if (firstKeptBase) primaryDie = { value: firstKeptBase.value, size: token.sides };
      criticalHits = tokenResult.diceData.criticalHits || 0;
    }
    dice.push(...termDice);
    total += sign * evaluated.total;
  }

  const kind = !primaryDie ? 'HIT'
    : primaryDie.value === 1 ? 'MISS'
      : primaryDie.value === primarySides ? 'CRIT' : 'HIT';

  return {
    total: Math.trunc(total),
    kind,
    dice,
    primaryDie,
    primarySides,
    advantageLevel,
    vicious,
    criticalHits,
    formula: split.formula,
  };
}

export function buildQuickFormula(selectedDice) {
  if (!Array.isArray(selectedDice) || !selectedDice.length) return '';
  const primarySides = selectedDice[0];
  const primaryCount = selectedDice.filter((s) => s === primarySides).length;
  const order = [];
  for (const sides of selectedDice) {
    if (sides !== primarySides && !order.includes(sides)) order.push(sides);
  }
  const terms = [`${primaryCount}d${primarySides}`];
  for (const sides of order) {
    const count = selectedDice.filter((s) => s === sides).length;
    terms.push(`${count}d${sides}`);
  }
  return terms.join(' + ');
}
