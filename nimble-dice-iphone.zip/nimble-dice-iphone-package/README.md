# Nimble Dice — iPhone-ready web app (v7)

This ZIP contains a static, installable web app for the Nimble tabletop RPG. The published site is in `nimble-dice-iphone-package/site/`.

## What is included

- **Quick Roller** — d4, d6, d8, d10, d12, and d20 buttons using cropped Classic Gold die artwork based on the image you supplied; the dice are the tap targets.
- **Calculator** — a dedicated formula keypad with digits, `d`, plus/minus, ADV, DIS, backspace, Clear, Roll, and Vicious.
- **Dice Sets** — named formulas in user-created folders, per-folder and per-set colors, edit/delete, and inline roll results. Set rolls stay in the Dice Sets tab.
- **Nimble rolling** — the included upstream `@nimble/dice` engine performs the primary dice-term's advantage/disadvantage keep/drop, exploding criticals, and Vicious bonus dice. The first die term is the primary pool; later die terms are additive bonus dice and do not independently set HIT/MISS/CRIT.
- **Numeric totals** — MISS never zeros out or replaces the numeric total. A primary natural 1 is red MISS; a primary maximum is yellow-orange CRIT; otherwise the result is green HIT.
- **No roll history** — latest results remain visible per screen/set until the next roll; there is no history ribbon.
- **Settings** — the top-right gear opens a settings panel with Classic Gold theme information plus optional sound and haptic feedback toggles. Preferences are saved locally.
- **Updated app icons and artwork** — Roller uses a simple pip-marked cube icon; the Roller Roll button is text-only. Die images are cleaned and supersampled for high-density iPhone displays, and the mismatched d6 side marking has been removed.
- **iPhone fit** — fixed bottom navigation, safe-area spacing, and compact layouts intended to avoid vertical scrolling on common iPhone screen sizes.
- **Offline after first load** — service worker caches the app and assets.

Saved folders and dice sets are stored locally in the browser on the device. They do not sync automatically across devices.

## Publish using the existing GitHub Pages workflow

This ZIP preserves the expected archive path `nimble-dice-iphone-package/site/`.

1. Replace the existing root-level `nimble-dice-iphone.zip` in your GitHub repository with this ZIP, keeping the filename exactly `nimble-dice-iphone.zip`.
2. Commit the change. Your current GitHub Actions workflow should deploy the new contents.
3. Open the GitHub Pages URL in Safari on your iPhone.
4. In Safari, choose **Share → Add to Home Screen**.
5. Launch the new home-screen icon. If the previous version is cached, fully close the app and reopen it after the deployment completes.

## Formula examples

- `1d20+5`
- `2d8+5 ADV1`
- `4d6+2`
- `1d8+3 DIS2`

The Calculator and Set editor add net ADV/DIS levels with buttons. Opposing taps cancel one-for-one. The text expression shows only the net result, such as `ADV2` or `DIS1`.

## Rules implementation note

The app reuses the supplied `@nimble/dice` engine's evaluation and tokenization. It enables exploding criticals on the first dice term, uses the first kept base die after ADV/DIS drops as the primary die, leaves the engine's numeric total intact for MISS, and rolls later dice terms as additive bonus dice. Vicious is applied to the primary term and the upstream engine adds its non-exploding bonus die(s) for critical hits.

This is an independent companion app, not an official Nimble product. The upstream `@nimble/dice` package README states that the package is MIT-licensed; its source and README are included for attribution/reference.


### Folder deletion (v6, retained in v7)

Each folder has a trash button in its heading. Deleting a folder asks for confirmation and clearly states how many saved dice sets inside it will also be permanently deleted. Results belonging to those sets are removed too. The library always keeps at least one folder; create another before deleting the last remaining folder.
