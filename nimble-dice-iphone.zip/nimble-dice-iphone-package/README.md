# Nimble Dice — iPhone web app prototype

This is a first installable-web-app prototype built around the actual `@nimble/dice` engine you supplied. It is not an App Store `.ipa`; iOS users install it from Safari using **Share → Add to Home Screen** after it is hosted on an HTTPS website.

## What is included

- `site/` — complete static website to publish. It includes the original Nimble dice engine compiled to browser JavaScript, an installable PWA manifest, icons, and a service worker.
- `source/` — the app TypeScript/CSS and the relevant original Nimble engine TypeScript files for reference.
- `UPSTREAM-NIMBLE-DICE-README.md` — original package README, including its notation and license statement.

## Current features

- d4, d6, d8, d10, d12, d20, d44, d66, d88 and d100.
- Advantage and disadvantage, handled by the supplied engine.
- Optional exploding criticals and Vicious dice.
- A switch for **Auto miss on primary 1**. Leave this on for attack rolls; turn it off for damage rolls where a natural 1 should not invalidate the roll.
- Result breakdown shows kept and discarded dice, primary die, explosions, Vicious dice, and final total.
- Recent roll history is stored locally in the browser.
- PWA caching allows offline use after the first successful visit.

## Publish it for iPhone

The website must be hosted on HTTPS; opening the files directly from the iPhone Files app is not enough to install a PWA.

1. Extract this ZIP.
2. Publish the **contents of the `site` folder** to a static HTTPS host. Keep the `engine` folder alongside `index.html` (do not upload only the HTML file).
3. Open the resulting HTTPS address in Safari on the iPhone.
4. Tap **Share** → **Add to Home Screen** → **Add**.
5. Launch Nimble Dice from the new Home Screen icon. After it has loaded once, the service worker can cache the app for offline use.

One route is GitHub Pages: create a repository, upload the contents of `site/` to the repository root, then enable Pages in **Settings → Pages**. GitHub will provide the HTTPS URL. If you want, I can walk you through the exact taps in Safari/GitHub once you choose a hosting route.

## Rules/engine notes

- The app calls `evaluateDiceFormula()` from the supplied engine.
- It enables `allowFumbles` only when the Auto miss switch is on. In the engine, a fumble makes the entire formula total zero.
- Exploding and Vicious behavior are requested through the engine's `!` and `v` notation.
- The engine's primary-die check is the first retained base die. For a one-die attack with advantage/disadvantage, the engine drops the lower/higher result respectively and the retained die is the primary die.
- For multi-die formulas, the engine retains its own global keep/drop behavior and first-retained-die primary selection. Review those edge cases against your table's exact Nimble rules before relying on them.

This is an independent prototype, not an official Nimble product. The upstream package README identifies the dice engine as MIT-licensed; retain upstream attribution/license terms when redistributing.
