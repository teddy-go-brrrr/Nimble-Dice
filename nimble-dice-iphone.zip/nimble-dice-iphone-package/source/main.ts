import { evaluateDiceFormula } from './engine/index.js';
import type { DiceFormulaResult, DiceTokenResult, CategorizedDie } from './engine/schemas.js';
import './style.css';

type Advantage = 'normal' | 'advantage' | 'disadvantage';
type HistoryEntry = { id: number; formula: string; total: number; fumble: boolean; detail: string; time: string };

const app = document.querySelector<HTMLDivElement>('#app')!;
const dice = [4, 6, 8, 10, 12, 20, 44, 66, 88, 100];
let sides = 20;
let count = 1;
let modifier = 0;
let advantage: Advantage = 'normal';
let exploding = true;
let vicious = false;
let autoMiss = true;
let lastFormula = '';
let lastResult: DiceFormulaResult | null = null;
let history: HistoryEntry[] = loadHistory();

function loadHistory(): HistoryEntry[] {
  try { return JSON.parse(localStorage.getItem('nimble-dice-history') || '[]').slice(0, 15); }
  catch { return []; }
}
function saveHistory() { localStorage.setItem('nimble-dice-history', JSON.stringify(history.slice(0, 15))); }
function formula(): string {
  const adv = advantage === 'advantage' ? 'a' : advantage === 'disadvantage' ? 'd' : '';
  const mods = `${exploding ? '!' : ''}${vicious ? 'v' : ''}${adv}`;
  const dieCount = (sides === 44 || sides === 66 || sides === 88) ? 1 : count;
  return `${dieCount}d${sides}${mods}${modifier === 0 ? '' : modifier > 0 ? `+${modifier}` : modifier}`;
}
function esc(value: unknown): string { return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!)); }
function dieLabel(d: CategorizedDie): string {
  const names: Record<string,string> = { normal:'Kept', critical:'Primary critical', explosion:'Explosion', vicious:'Vicious', dropped:'Dropped', fumble:'Natural 1' };
  return `${d.value} · ${names[d.category] || d.category}`;
}
function render() {
  app.innerHTML = `
    <main class="shell">
      <header class="topbar"><div class="mark">N</div><div><div class="eyebrow">TABLETOP TOOL</div><h1>Nimble <span>Dice</span></h1></div><button class="icon-button" id="help" aria-label="How to use">?</button></header>
      <section class="panel roller">
        <div class="section-head"><div><div class="eyebrow">01 / BUILD YOUR ROLL</div><h2>Choose your dice</h2></div><span class="pill">NIMBLE RPG</span></div>
        <div class="dice-grid">${dice.map(d => `<button class="die ${sides===d?'selected':''}" data-sides="${d}"><span>d${d}</span></button>`).join('')}</div>
        <div class="control-row"><div><label for="count">Number of dice</label><div class="stepper"><button data-count="-1" aria-label="Decrease dice">−</button><output>${count}</output><button data-count="1" aria-label="Increase dice">+</button></div></div><div class="modifier-control"><label for="modifier">Modifier</label><input id="modifier" type="number" inputmode="numeric" value="${modifier}" /></div></div>
        ${(sides===44||sides===66||sides===88)?'<p class="hint">Double-digit dice are rolled as a single tens-and-ones pair.</p>':''}
        <div class="divider"></div>
        <div class="eyebrow">02 / SPECIAL RULES</div>
        <label class="field-label">Roll state</label>
        <div class="segmented"><button data-adv="normal" class="${advantage==='normal'?'active':''}">Normal</button><button data-adv="advantage" class="${advantage==='advantage'?'active':''}">Advantage</button><button data-adv="disadvantage" class="${advantage==='disadvantage'?'active':''}">Disadvantage</button></div>
        <div class="toggles"><label class="toggle"><span><b>Exploding criticals</b><small>Primary die maximum triggers explosions</small></span><input id="exploding" type="checkbox" ${exploding?'checked':''}><i></i></label><label class="toggle"><span><b>Vicious</b><small>Add one non-exploding die per critical</small></span><input id="vicious" type="checkbox" ${vicious?'checked':''}><i></i></label><label class="toggle"><span><b>Auto miss on primary 1</b><small>Use for attack rolls; turn off for damage rolls</small></span><input id="auto-miss" type="checkbox" ${autoMiss?'checked':''}><i></i></label></div>
        <button class="roll-button" id="roll"><span>ROLL DICE</span><span class="arrow">↗</span></button>
        <div class="formula-preview">Formula <code>${esc(formula())}</code></div>
      </section>
      <section class="panel result-panel" id="result-panel">
        <div class="section-head"><div><div class="eyebrow">03 / YOUR RESULT</div><h2>Roll result</h2></div><span class="pill muted">READY</span></div>
        <div class="empty-result" id="empty"><div class="die-outline">🎲</div><p>Your roll will appear here.</p><small>Choose your dice and tap Roll Dice.</small></div>
        <div id="result"></div>
      </section>
      <section class="panel history-panel"><div class="section-head"><div><div class="eyebrow">RECENT ROLLS</div><h2>History</h2></div><button class="text-button" id="clear-history">Clear</button></div><div id="history-list"></div></section>
      <footer>Built around the open-source <strong>@nimble/dice</strong> engine. Roll results are generated on this device.</footer>
    </main>
    <div class="modal-backdrop hidden" id="modal"><div class="modal"><button class="close" id="close-modal">×</button><div class="eyebrow">QUICK GUIDE</div><h2>How this roller works</h2><ul><li><b>Advantage:</b> rolls an extra die and keeps the higher result.</li><li><b>Disadvantage:</b> rolls an extra die and keeps the lower result.</li><li><b>Natural 1:</b> a 1 on the primary retained die is an automatic miss.</li><li><b>Exploding:</b> only the primary die triggers an explosion by default.</li><li><b>Vicious:</b> adds a non-exploding die for each critical hit.</li></ul><p class="hint">This app uses the supplied Nimble dice package. Always compare table-specific rules and options with your current Nimble rulebook.</p></div></div>`;
  renderHistory();
  bind();
  if (lastResult) showResult(lastResult, lastFormula);
}
function bind() {
  app.querySelectorAll<HTMLButtonElement>('[data-sides]').forEach(b => b.addEventListener('click', () => { sides=Number(b.dataset.sides); if ([44,66,88].includes(sides)) count=1; render(); }));
  app.querySelectorAll<HTMLButtonElement>('[data-count]').forEach(b => b.addEventListener('click', () => { count=Math.max(1,Math.min(20,count+Number(b.dataset.count))); render(); }));
  app.querySelectorAll<HTMLButtonElement>('[data-adv]').forEach(b => b.addEventListener('click', () => { advantage=b.dataset.adv as Advantage; render(); }));
  app.querySelector<HTMLInputElement>('#modifier')?.addEventListener('change', e => { modifier=Math.max(-999,Math.min(999,Number((e.target as HTMLInputElement).value)||0)); render(); });
  app.querySelector<HTMLInputElement>('#exploding')?.addEventListener('change', e => { exploding=(e.target as HTMLInputElement).checked; render(); });
  app.querySelector<HTMLInputElement>('#vicious')?.addEventListener('change', e => { vicious=(e.target as HTMLInputElement).checked; render(); });
  app.querySelector<HTMLInputElement>('#auto-miss')?.addEventListener('change', e => { autoMiss=(e.target as HTMLInputElement).checked; render(); });
  app.querySelector('#roll')?.addEventListener('click', doRoll);
  app.querySelector('#clear-history')?.addEventListener('click', () => { history=[]; saveHistory(); renderHistory(); });
  app.querySelector('#help')?.addEventListener('click', () => app.querySelector('#modal')?.classList.remove('hidden'));
  app.querySelector('#close-modal')?.addEventListener('click', () => app.querySelector('#modal')?.classList.add('hidden'));
  app.querySelector('#modal')?.addEventListener('click', e => { if (e.target===e.currentTarget) app.querySelector('#modal')?.classList.add('hidden'); });
}
function doRoll() {
  try {
    const f = formula();
    // Fumbles are enabled for Nimble attack rolls. Exploding/Vicious are encoded in the formula.
    const result = evaluateDiceFormula(f, { allowFumbles: autoMiss });
    lastFormula=f;
    lastResult=result;
    showResult(result, f);
    const entry: HistoryEntry = { id: Date.now(), formula:f, total:result.total, fumble:result.isFumble, detail:result.displayString, time:new Date().toLocaleTimeString([], {hour:'numeric',minute:'2-digit'}) };
    history.unshift(entry); history=history.slice(0,15); saveHistory(); renderHistory();
    app.querySelector('#result-panel')?.scrollIntoView({behavior:'smooth',block:'nearest'});
  } catch (err) { const box=app.querySelector('#result')!; box.innerHTML=`<p class="error">${esc(err instanceof Error?err.message:String(err))}</p>`; }
}
function showResult(result: DiceFormulaResult, f: string) {
  app.querySelector('#empty')?.classList.add('hidden');
  const token = result.tokens.find((t): t is DiceTokenResult => t.type==='dice');
  const allDice = token?.diceData.dice || [];
  const primary = allDice.find(d => d.kept && !['explosion','vicious'].includes(d.category));
  const resultBox=app.querySelector<HTMLDivElement>('#result')!;
  resultBox.innerHTML = `
    <div class="result-total ${result.isFumble?'fumble':''}"><div class="result-label">${result.isFumble?'AUTOMATIC MISS':'FINAL TOTAL'}</div><div class="total-number">${result.isFumble?'MISS':result.total}</div><div class="result-formula">${esc(f)}</div></div>
    <div class="status-row">${result.isFumble?'<span class="status danger">Natural 1 · Automatic miss</span>':result.numCriticals>0?`<span class="status critical">${result.numCriticals} critical ${result.numCriticals===1?'hit':'hits'}</span>`:'<span class="status">No critical hit</span>'}${advantage!=='normal'?`<span class="status">${advantage==='advantage'?'Advantage':'Disadvantage'}</span>`:''}</div>
    <div class="breakdown-head"><b>Dice breakdown</b><span>${allDice.length} dice rolled</span></div>
    <div class="die-list">${allDice.map(d=>`<div class="die-result ${d.kept?'kept':'dropped'} ${d.category}"><span class="die-value">${d.value}</span><span class="die-info">${esc(dieLabel(d))}</span>${d===primary?'<span class="primary-tag">PRIMARY</span>':''}</div>`).join('')}</div>
    <div class="display-string"><span>Engine breakdown</span><code>${esc(result.displayString)}</code></div>`;
}
function renderHistory() {
  const list=app.querySelector<HTMLDivElement>('#history-list'); if(!list)return;
  list.innerHTML=history.length?history.map(h=>`<div class="history-item"><div><b>${esc(h.formula)}</b><small>${esc(h.time)} · ${h.fumble?'Automatic miss':esc(h.detail)}</small></div><strong class="${h.fumble?'miss':''}">${h.fumble?'MISS':h.total}</strong></div>`).join(''):'<div class="history-empty">Your recent rolls will be saved here.</div>';
}

if ('serviceWorker' in navigator && location.protocol !== 'file:') window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(()=>{}));
render();
